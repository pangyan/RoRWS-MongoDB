require 'test_helper'

class RacerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
