

```shell
$ rails g model Racer first_name last_name date_of_birth:date gender
```
